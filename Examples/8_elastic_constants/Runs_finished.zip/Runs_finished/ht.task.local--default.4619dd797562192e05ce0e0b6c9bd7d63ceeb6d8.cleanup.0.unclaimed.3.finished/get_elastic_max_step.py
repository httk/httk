from utilities import elastic_config

_, _, distortions, _ = elastic_config()
print(len(distortions))
